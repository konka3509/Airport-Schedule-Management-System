@extends('layouts.app')
@section('content')
<div class="container">
<div class="row">
<div class="col-md-4 offset-md-4">
<form action="{{route('airportupdate', $list->id)}}" method="post">
@csrf
  <div class="form-group">
    <label for="airport_name">Airport Name</label>
    <input name="airport_name" type="text" value="{{$list->airport_name}}" class="form-control" id="airport_name" aria-describedby="airport_name">
  </div>

  <div class="form-group">
    <label for="airport_id">Airport ID</label>
    <input name="airport_id" type="text" value="{{$list->airport_id}}" class="form-control" id="airport_id" aria-describedby="airport_id">
  </div>
  <button type="submit" class="btn btn-outline-info">UPDATE</button>
</form>
</div>
</div>
</div>

@endsection