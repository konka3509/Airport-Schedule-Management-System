@extends('layouts.app')
@section('content')
<div class="container">
<div class="row">
<div class="col-md-4 offset-md-4">
<form action="{{route('airportcreat')}}" method="post">
@csrf
  <div class="form-group">
    <label for="airport_name">Airport Name</label>
    <input name="airport_name" type="text" class="form-control" id="airport_name" aria-describedby="airport_name">
  </div>

  <div class="form-group">
    <label for="airport_id">Airport ID</label>
    <input name="airport_id" type="text" class="form-control" id="airport_id" aria-describedby="airport_id">
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>
</div>
</div>



@endsection
