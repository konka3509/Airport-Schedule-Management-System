@extends('layouts.app')
@section('content')
<div class="container">
	<a href="{{route('addairport')}}" class="m-3">
		<button type="button" class="btn btn-outline-primary">Add Airport</button>
	</a>

<div class="row">
<div class="col-md-12"><br>
<table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">SL</th>
      <th scope="col">Airport Name</th>
      <th scope="col">Airport ID</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  @foreach($lists as $list)
    <tr>
      <th scope="row">{{$loop->iteration}}</th>
      <td>{{$list->airport_name}}</td>
      <td>{{$list->airport_id}}</td>

<td>
<a href="{{url('/airport/information/list/edit')}}/{{$list->id}}" class="btn btn-outline-success">EDIT</a>
<a href="{{url('/airport/information/list/delate')}}/{{$list->id}}" class="btn btn-outline-danger">DELETE</a>
</td>
</tr>

 @endforeach
  </tbody>
</table>
</div>
</div>
</div>
@endsection