@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header">Dashboard</div>

            <div class="card-body">
              @if (session('status'))
                <div class="alert alert-success" role="alert">
                  {{ session('status') }}
                </div>
              @endif
					
              @if (Auth::user()->user_type == 1)
                <a href="{{route('userlist')}}" class="m-3 text-decoration-none">
                  <button type="button" class="btn btn-outline-primary p-3 mt-3 mb-3">User Management</button>
                </a>
              <a href="{{route('airportlist')}}" class="m-3 text-decoration-none">
                <button type="button" class="btn btn-outline-warning p-3 mt-3 mb-3">Airport</button>
              </a>
              @endif
              <a href="{{route('flightlist')}}" class="m-3 text-decoration-none">
                <button type="button" class="btn btn-outline-success p-3 mt-3 mb-3">Flight</button>
              </a>
              <a href="{{route('schedule_list')}}" class="m-3 text-decoration-none">
                <button type="button" class="btn btn-outline-info p-3 mt-3 mb-3">Schedule</button>
              </a>	
              <a href="{{route('noticelist')}}" class="m-3 text-decoration-none">
                <button type="button" class="btn btn-outline-secondary p-3 mt-3 mb-3">Notice</button>
              </a>	
              <a href="{{route('report_view')}}" class="m-3 text-decoration-none">
                <button type="button" class="btn btn-outline-danger p-3 mt-3 mb-3">Report</button>
              </a>	
              <br>
              <a href="{{route('get_airport_list')}}" target="_blank" class="m-3 text-decoration-none">
                <button type="button" class="btn btn-dark p-3 mt-3 mb-3">View Schedule</button>
              </a>			
          </div>
        </div>
      </div>
    </div>
</div>
@endsection
