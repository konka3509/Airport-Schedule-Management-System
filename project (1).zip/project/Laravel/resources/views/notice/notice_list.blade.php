@extends('layouts.app')
@section('content')
<div class="container">
	<a href="{{route('addnotice')}}" class="m-3">
		<button type="button" class="btn btn-outline-primary">Add Notice</button>
	</a>

  <div class="row">
    <div class="col-md-12 offset-md-12"><br>
      <table class="table table-striped">
        <thead>
          <tr>
            <th scope="col">SL</th>
            <th scope="col">Message</th>
            <th scope="col">Status</th>
            <th scope="col">Action</th>
          </tr>
        </thead>
        <tbody>
          @foreach($lists as $list)
            <tr>
              <th scope="row">{{$loop->iteration}}</th>
              <td>{{$list->message}}</td>
              @if ($list->active == 1)
                <td>Active</td>
              @else
                <td>Not Active</td>
              @endif ($list->active == 1)
              <td>
                <a href="{{url('/notice/information/list/edit')}}/{{$list->id}}" class="btn btn-outline-success">EDIT</a>
                <a href="{{url('/notice/information/list/delate')}}/{{$list->id}}" class="btn btn-outline-danger">DELETE</a>
              </td>
            </tr>
          @endforeach
        </tbody>
      </table>
    </div>
  </div>
</div>
@endsection