@extends('layouts.app')
@section('content')
<div class="container">
<div class="row">
<div class="col-md-4 offset-md-4">
<form action="{{route('noticecreat')}}" method="post">
@csrf
  <div class="form-group">
    <label for="airport_name">Message</label>
    <input name="message" type="text" class="form-control" id="message" aria-describedby="message">
  </div>

  <div class="form-group">
    <label for="active">Status</label>
    <select  name="active" id="active" class="form-control @error('active') is-invalid @enderror" required autocomplete="active">
		  <option value="1">Active</option>        
		  <option value="2">Not Active</option>        
    </select>
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>
</div>
</div>



@endsection
