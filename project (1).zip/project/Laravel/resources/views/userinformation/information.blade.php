@extends('layouts.app')
@section('content')
<div class="container">
<div class="row">
<div class="col-md-4 offset-md-4">
<form action="{{route('usercreat')}}" method="post">
@csrf

  <div class="form-group">
    <label for="name">Full Name</label>
    <input name="name" type="text" class="form-control" id="name" aria-describedby="name">
  </div>

  <div class="form-group">
    <label for="email">Email address</label>
    <input name="email" type="email" class="form-control" id="email" aria-describedby="emailHelp">
  </div>
  
  <div class="form-group">
    <label for="email_verified_at">Email Verified</label>
    <input name="email_verified_at" type="datetime" class="form-control" id="email_verified_at" aria-describedby="email_verified_at">
  </div>
  
  <div class="form-group">
    <label for="user_type">User Type</label>
    <input name="user_type" type="integer" class="form-control" id="user_type" aria-describedby="user_type">
  </div>
  
  <div class="form-group">
    <label for="password">Password</label>
    <input name="password" type="text" class="form-control" id="password">
  </div>

  <div class="form-group">
    <label for="airport_id">Airport ID</label>
    <input name="airport_id" type="text" class="form-control" id="airport_id" aria-describedby="airport_id">
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>
</div>
</div>
@endsection