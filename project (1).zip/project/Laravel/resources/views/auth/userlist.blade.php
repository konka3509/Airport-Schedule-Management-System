@extends('layouts.app')
@section('content')
<div class="container">
	<a href="{{route('register')}}" class="m-3">
		<button type="button" class="btn btn-outline-primary">Add User</button>
	</a>
	<div class="row">
		<div class="col-md-12"><br>
			<table class="table table-striped">
				<thead>
					<tr>
					  <th scope="col">SL</th>
					  <th scope="col">Name</th>
					  <th scope="col">E-Mail Address</th>
					  <th scope="col">User Type</th>
					  <th scope="col">Airport</th>
					  <th scope="col">Action</th>
					</tr>
				  </thead>
			  <tbody>
			  @foreach($lists as $list)
				<tr>
				  <th scope="row">{{$loop->iteration}}</th>
				  <td>{{$list->name}}</td>
				  <td>{{$list->email}}</td>
				  @if ($list->user_type == 1)
					<td>Admin</td>
				  @else
					<td>Manager</td>
				  @endif
				   <td>{{$list->airport->airport_name ?? ''}} ({{$list->airport->airport_id ?? 'Not set'}})</td>
			<td>
			<a href="{{url('/user/information/list/edit')}}/{{$list->id}}" class="btn btn-outline-success">EDIT</a>
			<a href="{{url('/user/information/list/delate')}}/{{$list->id}}" class="btn btn-outline-danger">DELETE</a>
			</td>
			</tr>

			 @endforeach
			  </tbody>
			</table>
		</div>
	</div>

@endsection