@extends('layouts.app')
@section('content')
<div class="container">
<div class="row">
<div class="col-md-4 offset-md-4">
<form action="{{route('userupdate', $list->id)}}" method="post">
@csrf
  <div class="form-group">
    <label for="name">Name</label>
    <input name="name" type="text" value="{{$list->name}}" class="form-control" id="name" aria-describedby="name">
  </div>

  <div class="form-group">
    <label for="email">Email address</label>
    <input name="email" type="email" value="{{$list->email}}" class="form-control" id="email" aria-describedby="emailHelp">
  </div>
  
  <div class="form-group">
    <label for="user_type">User Type</label>	
      <select  name="user_type" id="user_type" class="form-control @error('user_type') is-invalid @enderror" required autocomplete="user_type">
        <option value="1">Admin</option>
        <option value="2">Manager</option>
      </select>
   </div>
   <script>
		var user_type = document.getElementById("user_type").value = {{$list->user_type}};
	</script>

  <div class="form-group">
    <label for="password">Password</label>
    <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="new-password">
  </div>

  <div class="form-group">
    <label for="airport_id">Airport</label>
	<select  name="airport_id" id="airport_id" class="form-control @error('airport_name') is-invalid @enderror" required autocomplete="airport">
		@foreach($airport_list as $airport)
			<option value="{{$airport->id}}">{{$airport->airport_name}} ({{$airport->airport_id}})</option>
        @endforeach	
    </select>
  </div>
  <button type="submit" class="btn btn-outline-info">UPDATE</button>
</form>
</div>
</div>
</div>



@endsection