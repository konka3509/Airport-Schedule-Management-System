@extends('layouts.app')
@section('content')

	<div class="container">
	<a href="{{route('addschedule')}}" class="m-3">
		<button type="button" class="btn btn-outline-primary">Add schedule</button>
	</a>
	<div class="row">
		<div class="col-md-12"><br>
			<table class="table table-striped">
				<thead>
					<tr>
					  <th scope="col">SL</th>
					  <th scope="col">Flight</th>
					  <th scope="col">Departure At</th>
					  <th scope="col">Landing At</th>
					  <th scope="col">Departure Airport</</th>
	          <th scope="col">Landing Airport</th>
	          <th scope="col">Status</th>
					  <th scope="col">Delay Landing At</th>
					  <th scope="col">Delay Minutes</th>
					  <th scope="col">Action</th>
					</tr>
				  </thead>
			  <tbody> 
			  @foreach($lists as $list)
				<tr>
				  <th scope="row">{{$loop->iteration}}</th>
				  <td>{{$list->flight->flight_name}} ({{$list->flight->flight_id}})</td>
				  <td id="deperture_at_id_{{$list->id}}">{{$list->deperture_at}}</td>
				  <td id="landing_at_id_{{$list->id}}">{{$list->landing_at}}</td>
				  <td>{{$list->departure_airport->airport_name}} ({{$list->departure_airport->airport_id}})</td>
				  <td>{{$list->landing_airport->airport_name}} ({{$list->landing_airport->airport_id}})</td>
				  @if ($list->status == 0 )
            <td>ON TIME</td>
				  @elseif($list->status == 1 )
            <td>DELAYED</td>
				  @elseif($list->status == 2 )
            <td>RESCHEDULED</td>
				  @elseif($list->status == 3 )
            <td>CANCELLED</td>
				  @elseif($list->status == 4 )
            <td>LANDED</td>
				  @else	
            <td>TAKEN OFF</td>  
				  @endif
				   <td id="delay_landing_at_id_{{$list->id}}">{{$list->delay_landing_at}}</td>
				   <td id="delay_minutes_id_{{$list->id}}">{{$list->delay_minutes}}</td>
          <td>
            <a href="{{url('/schedule/information/list/edit')}}/{{$list->id}}" class="btn btn-outline-success">EDIT</a>
            <a href="{{url('/schedule/information/list/delate')}}/{{$list->id}}" class="btn btn-outline-danger">DELETE</a>
          </td>
          </tr>
          <script>
              document.getElementById('deperture_at_id_{{$list->id}}').innerHTML = (moment("{{$list->deperture_at}}", "YYYY-MM-DD HH:mm:ss").format("LLL"));
              document.getElementById('landing_at_id_{{$list->id}}').innerHTML = (moment("{{$list->landing_at}}", "YYYY-MM-DD HH:mm:ss").format("LLL"));
              if ("{{$list->delay_landing_at}}" != ""){
                document.getElementById('delay_landing_at_id_{{$list->id}}').innerHTML = (moment("{{$list->delay_landing_at}}", "YYYY-MM-DD HH:mm:ss").format("LLL"));
              }
              if ("{{$list->delay_minutes}}" != ""){
                document.getElementById('delay_minutes_id_{{$list->id}}').innerHTML = "{{$list->delay_minutes}}" + "min";
              }
          </script>
			 @endforeach
			  </tbody>
			</table>
		</div>
	</div>
</div>




@endsection