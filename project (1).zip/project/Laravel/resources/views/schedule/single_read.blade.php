@extends('layouts.app')
@section('content')
<div class="container">
<div class="row">
<div class="col-md-4 offset-md-4">
<form action="{{route('scheduleupdate', $list->id)}}" method="post">
@csrf
  <div class="form-group">
    <label for="flight_id">Flight</label>
    <select name="flight_id" id="flight_id" class="form-control @error('flight_name') is-invalid @enderror" required autocomplete="flight">
      @foreach($flight_list as $flight)
          <option value="{{$flight->id}}">{{$flight->flight_name}} ({{$flight->flight_id}})</option>
      @endforeach	
    </select>
  </div>
      <script>
		var flight_id = document.getElementById("flight_id").value = {{$list->flight_id}};
	</script>
  
  <div class="form-group">
    <label for="deperture_at">Departure At</label>
    <input name="deperture_at" type="datetime-local"  class="form-control" id="deperture_at" aria-describedby="deperture_at" required>
  </div>

  <div class="form-group">
    <label for="landing_at">Landing At</label>
    <input name="landing_at" type="datetime-local"  class="form-control" id="landing_at" aria-describedby="landing_at" required>
  </div>  
  
  <div class="form-group">
    <label for="departure_airport_id">Departure Airport</label>
    <select  name="departure_airport_id" id="departure_airport_id" class="form-control @error('airport_name') is-invalid @enderror" required autocomplete="airport">
      @foreach($airport_list as $airport)
        <option value="{{$airport->id}}">{{$airport->airport_name}} ({{$airport->airport_id}})</option>
      @endforeach	
    </select>
  </div> 
  
  <div class="form-group">
    <label for="landing_airport_id">Landing Airport</label>
    <select  name="landing_airport_id" id="landing_airport_id" class="form-control @error('airport_name') is-invalid @enderror" required autocomplete="airport">
      @foreach($airport_list as $airport)
        <option value="{{$airport->id}}">{{$airport->airport_name}} ({{$airport->airport_id}})</option>
      @endforeach	
    </select>
  </div>
  
  <div class="form-group">
    <label for="status">Status</label>
    <select  name="status" id="status" class="form-control @error('status') is-invalid @enderror" required autocomplete="airport">
		<option value="0">ON TIME</option>
		<option value="1">DELAYED</option>
		<option value="2">RECHEDULED</option>
		<option value="3">CANCELLED</option>
		<option value="4">LANDED</option>
		<option value="5">TAKEN OFF</option>
    </select>
		
  </div> 
  
  <div class="form-group">
    <label for="delay_landing_at">Delayed Landing At</label>
    <input name="delay_landing_at" type="datetime-local" value="{{$list->delay_landing_at}}" class="form-control" id="delay_landing_at" aria-describedby="delay_landing_at">
  </div>  
 
  <div class="form-group">
    <label for="delay_minutes">Delay Minutes</label>
    <input name="delay_minutes" type="number" value="{{$list->delay_minutes}}" class="form-control" id="delay_minutes" aria-describedby="delay_minutes">
  </div>  

  <button type="submit" class="btn btn-outline-info">UPDATE</button>
</form>
</div>
</div>
</div>






  
  <script>    
		var deperture_at = "{{$list->deperture_at}}".replace(" ", "T");
		document.getElementById("deperture_at").value = deperture_at;
		
		var landing_at = "{{$list->landing_at}}".replace(" ", "T");
		document.getElementById("landing_at").value = landing_at;
		
		var landing_at = "{{$list->landing_at}}".replace(" ", "T");
		document.getElementById("landing_at").value = landing_at;
		
		var delay_landing_at = "{{$list->delay_landing_at}}".replace(" ", "T");
		document.getElementById("delay_landing_at").value = delay_landing_at;
		
		var departure_airport_id = document.getElementById("departure_airport_id").value = "{{$list->departure_airport_id}}";   
		var landing_airport_id = document.getElementById("landing_airport_id").value = "{{$list->landing_airport_id}}";
    
    // disable airport from landing airport if it is selected in departure airport
    if ($('#departure_airport_id').val() != []){
      $("#landing_airport_id option[value=" + $('#departure_airport_id').val() + "]").attr('hidden', 'hidden').siblings().removeAttr('hidden');
    }
    
    $('#departure_airport_id').on('change', function(){      
      $("#landing_airport_id option[value=" + $('#departure_airport_id').val() + "]").attr('hidden', 'hidden').siblings().removeAttr('hidden');;
    
      if ($('#departure_airport_id').val() == $('#landing_airport_id').val()){        
        $("#landing_airport_id").val([]);        
      }
    });
    
    // selecting status option
		$("#status option[value={{$list->status}}]").attr('selected', 'selected');
    
    // calculating delay_minutes time diffrence from delay_landing_at - landing_at
    var delay_landing_at  = "{{$list->delay_landing_at}}";
    var landing_at = "{{$list->landing_at}}";
    var delay = moment.utc(moment(delay_landing_at,"YYYY-MM-DD HH:mm:ss").diff(moment(landing_at,"YYYY-MM-DD HH:mm:ss")));
    $('#delay_minutes').val((delay/1000)/60);
    $('#delay_minutes').on('click', function(){
      var delay_landing_at  = $('#delay_landing_at').val();
      var landing_at = $('#landing_at').val();
      var delay = moment.utc(moment(delay_landing_at,"YYYY-MM-DD HH:mm:ss").diff(moment(landing_at,"YYYY-MM-DD HH:mm:ss")));
      $('#delay_minutes').val((delay/1000)/60);
    });
    
	</script>

@endsection