<!DOCTYPE html>
<html lang="en" style="height:100%">
<head>
  
</head>
<body style="height:100%">  
  @if ($departure) 
    <iframe id="departure_frame" src="{{route('get_departure_list')}}" height="100%" width="100%" frameborder="0">Your browser doesnot support iframes<a href="myPageURL.htm"> click here to view the page directly. </a></iframe>
  
    <script>
      document.getElementById('departure_frame').src = "{{route('get_departure_list')}}"+"/?airport="+(window.location.href).split('airport=')[1];
      setInterval(function() { 
        document.getElementById('departure_frame').src = "{{route('get_departure_list')}}"+"/?airport="+(window.location.href).split('airport=')[1];
        document.getElementById('departure_frame').contentWindow.location.reload(true);
      }, 60000);    
    </script>
  
  @else
    <iframe id="landing_frame" src="{{route('get_landing_list')}}" height="100%" width="100%" frameborder="0">Your browser doesnot support iframes<a href="myPageURL.htm"> click here to view the page directly. </a></iframe>
  
    <script>
      document.getElementById('landing_frame').src = "{{route('get_landing_list')}}"+"/?airport="+(window.location.href).split('airport=')[1];
      setInterval(function() { 
        document.getElementById('landing_frame').src = "{{route('get_landing_list')}}"+"/?airport="+(window.location.href).split('airport=')[1]; 
        document.getElementById('landing_frame').contentWindow.location.reload(true); 
      }, 60000);    
    </script>
  
  @endif 
  

</body>
</html>
