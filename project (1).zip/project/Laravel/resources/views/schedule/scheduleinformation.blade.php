@extends('layouts.app')
@section('content')
<div class="container">
<div class="row">
<div class="col-md-4 offset-md-4">
<form action="{{route('schedulecreat')}}" method="post">
@csrf
  <div class="form-group">
    <label for="flight_id">Flight</label>
    <select name="flight_id" id="flight_id" class="form-control @error('flight_name') is-invalid @enderror" required autocomplete="flight">
	@foreach($flight_list as $flight)
			<option value="{{$flight->id}}">{{$flight->flight_name}} ({{$flight->flight_id}})</option>
    @endforeach	
    </select>
  </div>
  
  <div class="form-group">
    <label for="deperture_at">Deperture At</label>
    <input name="deperture_at" type="datetime-local" class="form-control" id="deperture_at" aria-describedby="deperture_at" required>
  </div>

  <div class="form-group">
    <label for="landing_at">landing At</label>
    <input name="landing_at" type="datetime-local" class="form-control" id="landing_at" aria-describedby="landing_at" required>
  </div>  
  
  <div class="form-group">
    <label for="departure_airport_id">Deperture Airport</label>
	<select  name="departure_airport_id" id="departure_airport_id" class="form-control @error('airport_name') is-invalid @enderror" required autocomplete="airport">
		@foreach($airport_list as $airport)
			<option value="{{$airport->id}}">{{$airport->airport_name}} ({{$airport->airport_id}})</option>
        @endforeach	
    </select>
  </div>
  
    <div class="form-group">
    <label for="landing_airport_id">Landing Airport</label>
	<select  name="landing_airport_id" id="landing_airport_id" class="form-control @error('airport_name') is-invalid @enderror" required autocomplete="airport">
		  <option selected hidden disabled>Select one</option>
      @foreach($airport_list as $airport)
			<option value="{{$airport->id}}">{{$airport->airport_name}} ({{$airport->airport_id}})</option>
        @endforeach	
    </select>
  </div>
  
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>
</div>
</div>



<script>
    // disable airport from landing airport if it is selected in departure airport
    if ($('#departure_airport_id').val() != []){
      $("#landing_airport_id option[value=" + $('#departure_airport_id').val() + "]").attr('hidden', 'hidden').siblings().removeAttr('hidden');
    }

    $('#departure_airport_id').on('change', function(){      
      $("#landing_airport_id option[value=" + $('#departure_airport_id').val() + "]").attr('hidden', 'hidden').siblings().removeAttr('hidden');;

      if ($('#departure_airport_id').val() == $('#landing_airport_id').val()){        
        $("#landing_airport_id").val([]);        
      }
    });
</script>


@endsection