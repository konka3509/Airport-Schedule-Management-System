@extends('layouts.app')
@section('content')
<div class="container">
	<a href="{{route('addflight')}}" class="m-3">
		<button type="button" class="btn btn-outline-primary">Add Flight</button>
	</a>

<div class="row">
<div class="col-md-12"><br>
<table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">SL</th>
      <th scope="col">Flight Name</th>
      <th scope="col">Flight ID</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  @foreach($lists as $list)
    <tr>
      <th scope="row">{{$loop->iteration}}</th>
      <td>{{$list->flight_name}}</td>
      <td>{{$list->flight_id}}</td>

<td>
<a href="{{url('/flight/information/list/edit')}}/{{$list->id}}" class="btn btn-outline-success">EDIT</a>
<a href="{{url('/flight/information/list/delate')}}/{{$list->id}}" class="btn btn-outline-danger">DELETE</a>
</td>
</tr>

 @endforeach
  </tbody>
</table>
</div>
</div>
</div>
@endsection