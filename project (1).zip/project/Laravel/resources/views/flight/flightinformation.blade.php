@extends('layouts.app')
@section('content')
<div class="container">
<div class="row">
<div class="col-md-4 offset-md-4">
<form action="{{route('flightcreat')}}" method="post">
@csrf
  <div class="form-group">
    <label for="flight_name">Flight Name</label>
    <input name="flight_name" type="text" class="form-control" id="flight_name" aria-describedby="flight_name">
  </div>

  <div class="form-group">
    <label for="flight_id">Flight ID</label>
    <input name="flight_id" type="text" class="form-control" id="flight_id" aria-describedby="flight_id">
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>
</div>
</div>



@endsection