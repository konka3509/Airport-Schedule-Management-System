<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSchedulesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('schedules', function (Blueprint $table) {
           $table->bigIncrements('id');
		   $table->string('flight_id');
		   $table->dateTime('deperture_at');
		   $table->dateTime('landing_at');
		   $table->string('departure_airport_id');
		   $table->string('landing_airport_id');
		   $table->integer('status')->default('0'); // default is regular
		   $table->dateTime('delay_landing_at')->nullable();
		   $table->timestamp('delay_minutes')->nullable();
		   $table->rememberToken();
       $table->timestamps();
		   // $table->date('landing_date');
		   // $table->time('landing_time');
		   // $table->date('deperture_date');
		   // $table->time('deperture_time');
		   // $table->date('delay_adjust_date')->nullable();
		   // $table->time('delay_adjust_time')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('schedules');
    }
}
