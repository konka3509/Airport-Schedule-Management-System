<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class ScheduleUpdate02ToSchedulesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('schedules', function (Blueprint $table) {
           $table->dateTime('old_deperture_at');
           $table->dateTime('old_landing_at');
           $table->integer('time_changed_for_flight')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('schedules', function (Blueprint $table) {
            $table->dropColumn('old_deperture_at');
            $table->dropColumn('old_landing_at');
            $table->dropColumn('time_changed_for_flight');
        });
    }
}
