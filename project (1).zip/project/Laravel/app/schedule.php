<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class schedule extends Model
{
        protected $fillable = [
        'flight_id','deperture_at','landing_at','departure_airport_id','landing_airport_id','status','delay_landing_at', 'delay_minutes'
    ];
	
	
	
	    public function flight()
    {
        return $this->belongsTo('App\flights');
    }
	
	    public function landing_airport()
    {
        return $this->belongsTo('App\airports','landing_airport_id');
    }
	
	    public function departure_airport()
    {
        return $this->belongsTo('App\airports','departure_airport_id');
    }
}
