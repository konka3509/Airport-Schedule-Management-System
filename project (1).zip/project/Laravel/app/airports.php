<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class airports extends Model
{
        protected $fillable = [
        'airport_name', 'airport_id'
    ];
}
