<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\schedule;
use App\flights;
use App\airports;
use App\notice;
use Carbon\Carbon;


class scheduleController extends Controller
{
	
	public function __construct()
	{
		$this->middleware('auth');
	}

	function addschedule()
	{ 
		$airport_list=airports::all()->sortBYDesc('id');
		$flight_list=flights::all()->sortBYDesc('id');
		return view('schedule.scheduleinformation', compact( 'airport_list','flight_list'));
	}
	
	function schedulecreat(Request $Request ){
		schedule::insert([	
        'flight_id'=>$Request->flight_id,
        'deperture_at'=>$Request->deperture_at,
        'landing_at'=>$Request->landing_at,
        'old_deperture_at'=>$Request->deperture_at,
        'old_landing_at'=>$Request->landing_at,
        'departure_airport_id'=>$Request->departure_airport_id,
        'landing_airport_id'=>$Request->landing_airport_id,
			
	     ]);	
        $Request->session()->flash('success','Succesfully Schedule Data Inserted.'); 		
	    return Redirect()->route('schedule_list');
  }
		
		
  function schedule_list(){
    $lists=schedule::all()->sortBYDesc('id');
    return view('schedule.schedule_list',compact('lists'));
  }
		
		
	function get_departure_list(Request $Request){
      $departure = true;
      $from = Carbon::today()->toDateString();
      $to = Carbon::today()->addDays(1);;
			$notices = notice::where('active', 1)->get()->sortBY('deperture_at');
      
      $lists = schedule::where('departure_airport_id', '=', auth()->user()->airport_id)
      ->whereBetween('deperture_at', [$from, $to])
      ->get()->sortBY('deperture_at');
    return view('schedule.schedule_public.index',compact('lists', 'departure', 'notices'));
  }
		
		
  function get_landing_list(Request $Request){
    $departure = false;
    $from = Carbon::today()->toDateString();
    $to = Carbon::today()->addDays(1);
		$notices = notice::where('active', 1)->get()->sortBY('deperture_at');
      
    $lists = schedule::where('landing_airport_id', '=', auth()->user()->airport_id)
    ->whereBetween('landing_at', [$from, $to])
    ->get()->sortBY('landing_at');
    return view('schedule.schedule_public.index',compact('lists', 'departure', 'notices'));
  }
		
	function get_departure(Request $Request){
    $departure = true;
    return view('schedule.schedule_public.iframe_show',compact('departure'));
  }
		
	function get_landing(Request $Request){
    $departure = false;
    return view('schedule.schedule_public.iframe_show',compact('departure'));
  }
     
    
  function reschedule($id){
    // get edited flight details from schedule update
    $list = schedule::findorfail($id);
    // return dd($list);
    
    // check flight delayed or not
    if($list->status == 1){
      // if delayed then how many minutes delayed from landing time
      $from = Carbon::parse($list->landing_at);
      $to = Carbon::parse($list->delay_landing_at);
      $delay_time = $to->diffInMinutes($from);
      // return dd($from, $to, $delay_time);
      
      $next_flight = schedule::where('flight_id', $list->flight_id)->where('id', '>', $list->id)->first();
      // return dd($next_flight);        
      
      if($delay_time < 60){
        if(Carbon::parse($next_flight->deperture_at)->diffInMinutes(Carbon::parse($list->delay_landing_at)) < 60){
          //  if delay time is in between 1 to 59 min then add delay time with next flight, if next flight is one hour later
          $get_next_fligh_total_journey_minute = Carbon::parse($next_flight->landing_at)->diffInMinutes(Carbon::parse($next_flight->deperture_at));
          $next_flight->deperture_at = Carbon::parse($next_flight->deperture_at)->addMinutes($delay_time);
          $next_flight->landing_at = Carbon::parse($next_flight->deperture_at)->addMinutes($get_next_fligh_total_journey_minute);
          $next_flight->status = 2;   // as flight delayed so status will also be rescheduled
          $next_flight->time_changed_for_flight = $list->id;   // for this flight schedule delayed
          $next_flight->save();
          
          $this->recheck_schedules($next_flight);    // checking next flights so that if necessary then reschedule
        }
      }
      else {
        $next_flights = schedule::where('flight_id', $list->flight_id)->where('id', '>', $list->id)
        ->where('deperture_at', '<=', $list->delay_landing_at)->get();
        // return dd($next_flights); 
        
        //  delay time conflict / over delay with next scheduled flight so next flight canceled
        $last_flight_from_foreach_loop = null;
        
        foreach ($next_flights as $next_flight){
          $next_flight->status = 3;   // as flight delayed so status will also be canceled
          $next_flight->time_changed_for_flight = $list->id;   // for this flight schedule canceled
          $next_flight->save();
          $last_flight_from_foreach_loop = $next_flight;
        }
        
        if ($last_flight_from_foreach_loop != null){
          // cancelling related flight of last_fligh_from_foreach_loop
          // e.g. last_fligh_from_foreach_loop->landing_airport_id == DAC on the other hand next flight of the airline is
          // departure_airport_id == DAC. so its necessary to canceled next flight too as flight is still in CGP
          $next_related_flight = schedule::where('flight_id', $last_flight_from_foreach_loop->flight_id)
          ->where('id', '>', $last_flight_from_foreach_loop->id)
          ->where('departure_airport_id', $last_flight_from_foreach_loop->landing_airport_id)->first();
          if ($next_related_flight != null){
            $next_related_flight->status = 3;   // as flight delayed so status will also be canceled
            $next_related_flight->time_changed_for_flight = $list->id;   // for this flight schedule canceled
            $next_related_flight->save();
            $last_flight_from_foreach_loop = $next_related_flight;
          }
          
          $next_flight = schedule::where('flight_id', $last_flight_from_foreach_loop->flight_id)
          ->where('id', '>', $last_flight_from_foreach_loop->id)->first();
          // return dd($next_flight);
          if ($next_flight != null){
            $count_delay = Carbon::parse($next_flight->deperture_at)->diffInMinutes(Carbon::parse($list->delay_landing_at));
            $count_gap_time = Carbon::parse($next_flight->deperture_at)->diffInMinutes(Carbon::parse($last_flight_from_foreach_loop->landing_at));
            // return dd($count_delay, $count_gap_time);
            if($count_delay < 59){
              $get_next_fligh_total_journey_minute = Carbon::parse($next_flight->landing_at)->diffInMinutes(Carbon::parse($next_flight->deperture_at));
              // return dd($count_delay, $count_gap_time, $get_next_fligh_total_journey_minute);
              $next_flight->deperture_at = Carbon::parse($list->delay_landing_at)->addMinutes($count_gap_time);
              $next_flight->landing_at = Carbon::parse($next_flight->deperture_at)->addMinutes($get_next_fligh_total_journey_minute);
              $next_flight->status = 2;   // as flight delayed so status will also be rescheduled
              $next_flight->time_changed_for_flight = $list->id;   // for this flight schedule delayed
              $next_flight->save();          
              $this->recheck_schedules($next_flight);
            }   
          }                   
        }
      }
    }			
  }
    
  function recheck_schedules($flight){
    $next_flights = schedule::where('flight_id', $flight->flight_id)->where('id', '>', $flight->id)->get();
    // return dd($next_flights);
    foreach ($next_flights as $next_flight) {
      $count_delay = Carbon::parse($next_flight->deperture_at)->diffInMinutes(Carbon::parse($flight->landing_at));
      $count_gap_time = Carbon::parse($next_flight->deperture_at)->diffInMinutes(Carbon::parse($flight->old_landing_at));
      // return dd($count_delay, $count_gap_time);
      if($count_delay > 59){
        // As next flight has more than 59 minutes before take off so no need to change schedule any more
        break;
      }
      else {
        $get_next_fligh_total_journey_minute = Carbon::parse($next_flight->landing_at)->diffInMinutes(Carbon::parse($next_flight->deperture_at));
        $next_flight->deperture_at = Carbon::parse($flight->landing_at)->addMinutes($count_gap_time);
        $next_flight->landing_at = Carbon::parse($next_flight->deperture_at)->addMinutes($get_next_fligh_total_journey_minute);
        $next_flight->status = 2;   // as flight delayed so status will also be rescheduled
        $next_flight->time_changed_for_flight = $flight->id;   // for this flight schedule delayed
        $next_flight->save();
        
        $flight = $next_flight;          
      }
    }      
  }    
		
  function single_read($id){
    // $this->reschedule($id);
    $list=schedule::findorfail($id);
    $flight_list=flights::all()->sortBYDesc('id');
    $airport_list=airports::all()->sortBYDesc('id');
    return view('schedule.single_read',compact('list', 'flight_list', 'airport_list'));
  }				
  
  function scheduleupdate(Request $Request, $id){
    $list = schedule::findorfail($id);
    $list->flight_id = $Request->flight_id;
    $list->deperture_at = $Request->deperture_at;
    $list->landing_at = $Request->landing_at;
    $list->departure_airport_id = $Request->departure_airport_id;
    $list->landing_airport_id = $Request->landing_airport_id;
    $list->status = $Request->status;
    $list->delay_landing_at = $Request->delay_landing_at;
    $list->delay_minutes = $Request->delay_minutes;
    $list->save();
    
    $this->reschedule($id);
    
    $Request->session()->flash('success','Succesfully Schedule Data Updated.');
    return Redirect()->route('schedule_list');
  }
		
		
  function single_read_dlt(Request $Request, $id){
    schedule::findorfail($id)->delete();
    $Request->session()->flash('success','Succesfully Schedule Data delated.');		
    return Redirect()->back();
  }
    function submit(Request $Request){
    $Request->session()->flash('data','Data is submited successfully');
    return redirect()->route('schedule_list');
  }
}
