<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\notice;

class NoticeController extends Controller
{
  // checking user is logged in or not. Withour loggedin noone can use this controller
  public function __construct()
  {
      $this->middleware('auth');
  }
  
  function addnotice()
	{
		return view('notice.noticeinformation');
	}	
	
	function noticecreat(Request $Request)
	{
		notice::insert([	
      'message'=>$Request->message,
      'active'=>$Request->active,	
    ]);
    $Request->session()->flash('success','Succesfully Notice Added.');
		return Redirect()->route('noticelist');			
	}
	
	function noticelist()
	{
		$lists=notice::all()->sortBYDesc('id');
		return view('notice.notice_list',compact('lists'));
	}	
	
	function single_read($id)
	{
		$list=notice::findorfail($id);
		return view('notice.single_read',compact('list'));
	}	
	
	function noticeupdate(Request $Request, $id)
	{
		$list = notice::findorfail($id);		
		$list->message = $Request->message;
		$list->active = $Request->active;	
		$list->save();
		$Request->session()->flash('success','Succesfully Notice Updated.');
		return Redirect()->route('noticelist');
	}	
	
	function single_read_dlt(Request $Request, $id)
	{
		notice::findorfail($id)->delete();
    $Request->session()->flash('success','Succesfully Notice Delated.');		
		return Redirect()->back();
	}
  
  function submit(Request $Request){
    $Request->session()->flash('data','data is submited successfully');
    return redirect()->route('noticelist');
  }
}
