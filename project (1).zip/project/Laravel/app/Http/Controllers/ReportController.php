<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\schedule;
use App\flights;
use App\airports;
use App\notice;
use Carbon\Carbon;

class ReportController extends Controller
{
  // checking user is logged in or not. Without logged in no one can use this controller
  public function __construct(){
      $this->middleware('auth');
  }
  
  function view(Request $request){
    $lists = $lists=schedule::all()->sortBYDesc('id');
    $get_date = $request->date;
    $get_month = $request->month;
    
    if($get_date == null & $get_month == null){
      $lists=schedule::where('deperture_at', '>=', Carbon::today())
      ->where('landing_at', '<=', Carbon::tomorrow())->get()->sortBYDesc('id');
    } else if ($get_date != null){
      $lists=schedule::where('deperture_at', '>=', Carbon::parse($get_date))
      ->where('landing_at', '<=', Carbon::parse($get_date)->addDays(1))->get()->sortBYDesc('id');
    }else {
      $lists=schedule::where('deperture_at', '>=', Carbon::parse($get_month))
      ->where('landing_at', '<=', Carbon::parse($get_month)->addMonth(1))->get()->sortBYDesc('id');
    }
		return view('report.report', compact('lists'));
	}	
}
