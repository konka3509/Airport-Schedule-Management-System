<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\schedule;
use App\flights;
use App\airports;
use App\notice;
use Carbon\Carbon;


class ScheduleViewController extends Controller
{
	
	function get_airport_list(Request $Request){      
      $lists = airports::all()->sortBY('id');
    return view('schedule.schedule_public.airport_list',compact('lists'));
  }
	
	function get_departure_list(Request $Request){
    $departure = true;
    $from = Carbon::today()->toDateString();
    $to = Carbon::today()->addDays(1);;
    $notices = notice::where('active', 1)->get()->sortBY('deperture_at');
    $airport_id = airports::where('airport_id', $Request->airport)->first();
    
    $lists = schedule::where('departure_airport_id', $airport_id->id)
    ->whereBetween('deperture_at', [$from, $to])->get()->sortBY('deperture_at');
    return view('schedule.schedule_public.index',compact('lists', 'departure', 'notices'));
  }
		
		
  function get_landing_list(Request $Request){
    $departure = false;
    $from = Carbon::today()->toDateString();
    $to = Carbon::today()->addDays(1);
		$notices = notice::where('active', 1)->get()->sortBY('deperture_at');
    $airport_id = airports::where('airport_id', $Request->airport)->first();
      
    $lists = schedule::where('landing_airport_id', $airport_id->id)
    ->whereBetween('landing_at', [$from, $to])->get()->sortBY('landing_at');
    return view('schedule.schedule_public.index',compact('lists', 'departure', 'notices'));
  }
		
	function get_departure(Request $Request){
    $departure = true;
    return view('schedule.schedule_public.iframe_show',compact('departure'));
  }
		
	function get_landing(Request $Request){
    $departure = false;
    return view('schedule.schedule_public.iframe_show',compact('departure'));
  }
    
}
