<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\airports;
class airportinformationContoller extends Controller
{
	// checking user is logged in or not. Withour loggedin noone can use this controller
    public function __construct()
    {
        $this->middleware('auth');
    }
    function addairport()
	{
		return view('airportinformation.airportinformation');
	}
	
	
	function airportcreat(Request $Request)
	{
		airports::insert([
	
	'airport_name'=>$Request->airport_name,
	'airport_id'=>$Request->airport_id,
	
	]);
	$Request->session()->flash('success','Succesfully Flight Data Inserted.');
		return Redirect()->route('airportlist');
		
		
	}
	
	
	function airportlist()
	{
		$lists=airports::all()->sortBYDesc('id');
		return view('airportinformation.airport_list',compact('lists'));
	}
	
	
	function single_read($id)
	{
		$list=airports::findorfail($id);
		return view('airportinformation.single_read',compact('list'));
	}
	
	
	function airportupdate(Request $Request, $id)
	{
		$list = airports::findorfail($id);		
		$list->airport_name = $Request->airport_name;
		$list->airport_id = $Request->airport_id;	
		$list->save();
		$Request->session()->flash('success','Succesfully Airport Data Updated.');
		return Redirect()->route('airportlist');
	}
	
	
	function single_read_dlt(Request $Request, $id)
	{
		airports::findorfail($id)->delete();
        $Request->session()->flash('success','Succesfully Airport Data delated.');		
		return Redirect()->back();
	}
		function submit(Request $Request){
		$Request->session()->flash('data','data is submited successfully');
		return redirect()->route('airportlist');}
}
