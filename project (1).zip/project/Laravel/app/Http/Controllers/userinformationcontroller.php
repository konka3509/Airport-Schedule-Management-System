<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Illuminate\Support\Facades\Hash;


class userinformationcontroller extends Controller
{
    function index()
	{
	//echo"string";
	return view('userinformation.information');
	}
	    function usercreat(Request $Request)
	{
	User::insert([
	'name'=>$Request->name,
	'email'=>$Request->email,
	'email_verified_at'=>$Request->email_verified_at,
	'user_type'=>$Request->user_type,
	'password'=>Hash::make($Request->password),
	'airport_id'=>$Request->airport_id,
	
	]);

	}
}
