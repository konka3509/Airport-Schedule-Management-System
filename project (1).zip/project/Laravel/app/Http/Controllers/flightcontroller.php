<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\flights;
class flightcontroller extends Controller
{
	// checking user is logged in or not. Withour loggedin noone can use this controller
    public function __construct()
    {
        $this->middleware('auth');
    }
	
	//flight from
    function addflight(){
		return view('flight.flightinformation');
	}
	
	function flightcreat(Request $Request){
		flights::insert([	
			'flight_name'=>$Request->flight_name,
			'flight_id'=>$Request->flight_id,		
		]);
        $Request->session()->flash('success','Succesfully Flight Data Inserted.'); 		
		return Redirect()->route('flightlist');
	}
	
	function flightlist(){
		$lists=flights::all()->sortBYDesc('id');
		return view('flight.flight_list',compact('lists'));
	}
	
	function single_read($id){
		$list=flights::findorfail($id);
		return view('flight.single_read',compact('list'));
	}
	
	function flightupdate(Request $Request, $id){
		$list = flights::findorfail($id);
		$list->flight_name = $Request->flight_name;
		$list->flight_id = $Request->flight_id;	
		$list->save();
		$Request->session()->flash('success','Succesfully Flight Data Updated.');
		return Redirect()->route('flightlist');
	}
	
	function single_read_dlt(Request $Request, $id){
		flights::findorfail($id)->delete();
		$Request->session()->flash('success','Succesfully Flight Data delated.');		
		return Redirect()->back();
	}
	
	function submit(Request $Request){
		$Request->session()->flash('data','data is submited successfully');
		return redirect()->route('flightlist');
	}
}