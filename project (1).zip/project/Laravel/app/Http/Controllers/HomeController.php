<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\User;
use App\airports;
use Illuminate\Support\Facades\Hash;

class HomeController extends Controller
{   /**
     * Create a new controller instance.
     *
     * @return void
     */
	 // checking user is logged in or not. Withour loggedin noone can use this controller
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('home');
    }
		function userlist(){
			$lists=User::all()->sortBYDesc('id');
			return view('auth.userlist',compact('lists'));
		}
	
		function single_read($id){
			$list=User::findorfail($id);
			$airport_list=airports::all()->sortBYDesc('id');
			return view('auth.single_read',compact('list', 'airport_list'));		}
		
		function userupdate(Request $Request, $id){
			$list = User::findorfail($id);
			$list->name = $Request->name;
			$list->email = $Request->email;
			$list->user_type = $Request->user_type;
			$list->password = Hash::make($Request->password);
			$list->airport_id = $Request->airport_id;
			$list->save();
			$Request->session()->flash('success','Succesfully User Data Updated.');
			return Redirect()->route('userlist');
		}
	
	    function single_read_dlt(Request $Request, $id){
			User::findorfail($id)->delete();
			$Request->session()->flash('success','Succesfully User Data delated.');		
			return Redirect()->back();
		}
	    function submit(Request $Request){
			$Request->session()->flash('data','Data is submited successfully');
			return redirect()->route('userlist');
		}
}
