<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
//schedule
Route::get('/schedule/list','ScheduleViewController@get_airport_list')->name('get_airport_list');
Route::get('/schedule/information/departure/list','ScheduleViewController@get_departure_list')->name('get_departure_list');
Route::get('/schedule/information/departure/','ScheduleViewController@get_departure')->name('get_departure');
Route::get('/schedule/information/landing/','ScheduleViewController@get_landing')->name('get_landing');
Route::get('/schedule/information/landing/list','ScheduleViewController@get_landing_list')->name('get_landing_list');
Route::get('/schedule/information','scheduleController@addschedule')->name('addschedule');
Route::post('/schedule/information/creat','scheduleController@schedulecreat')->name('schedulecreat');
Route::post('/schedule/information/update/{id}','scheduleController@scheduleupdate')->name('scheduleupdate');
Route::get('/schedule/information/list','scheduleController@schedule_list')->name('schedule_list');
Route::get('/schedule/information/list/edit/{id}','scheduleController@single_read')->name('single_read');
Route::get('/schedule/information/list/delate/{id}','scheduleController@single_read_dlt')->name('single_read_dlt');
//flight
Route::get('/flight/information','flightcontroller@addflight')->name('addflight');
Route::post('/flight/information/creat','flightcontroller@flightcreat')->name('flightcreat');
Route::post('/flight/information/update/{id}','flightcontroller@flightupdate')->name('flightupdate');
Route::get('/flight/information/list','flightcontroller@flightlist')->name('flightlist');
Route::get('/flight/information/list/edit/{id}','flightcontroller@single_read')->name('single_read');
Route::get('/flight/information/list/delate/{id}','flightcontroller@single_read_dlt')->name('single_read_dlt');
//airport
Route::get('/airport/information','airportinformationContoller@addairport')->name('addairport');
Route::post('/airport/information/creat','airportinformationContoller@airportcreat')->name('airportcreat');
Route::post('/airport/information/update/{id}','airportinformationContoller@airportupdate')->name('airportupdate');
Route::get('/airport/information/list','airportinformationContoller@airportlist')->name('airportlist');
Route::get('/airport/information/list/edit/{id}','airportinformationContoller@single_read')->name('single_read');
Route::get('/airport/information/list/delate/{id}','airportinformationContoller@single_read_dlt')->name('single_read_dlt');
//user
Route::get('/user/information','userinformationcontroller@index');
Route::post('/user/information/creat','userinformationcontroller@usercreat')->name('usercreat');

// notice
Route::get('/notice/information','noticecontroller@addnotice')->name('addnotice');
Route::post('/notice/information/creat','noticecontroller@noticecreat')->name('noticecreat');
Route::post('/notice/information/update/{id}','noticecontroller@noticeupdate')->name('noticeupdate');
Route::get('/notice/information/list','noticecontroller@noticelist')->name('noticelist');
Route::get('/notice/information/list/edit/{id}','noticecontroller@single_read')->name('notice_single_read');
Route::get('/notice/information/list/delate/{id}','noticecontroller@single_read_dlt')->name('notice_single_read_dlt');

// report
Route::get('/report','ReportController@view')->name('report_view');

//home
// Route::get('/', function () {
    // return view('welcome');
// });
Route::get('/', 'HomeController@index')->name('home');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::post('/user/information/update/{id}','HomeController@userupdate')->name('userupdate');
Route::get('/user/information/list','HomeController@userlist')->name('userlist');
Route::get('/user/information/list/edit/{id}','HomeController@single_read')->name('single_read');
Route::get('/user/information/list/delate/{id}','HomeController@single_read_dlt')->name('single_read_dlt');