<!DOCTYPE html>
<html lang="en" style="height:100%">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Airport Schedule Management System</title>
  <!-- MDB icon -->
  <link rel="icon" href="img/mdb-favicon.ico" type="image/x-icon">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">
  <!-- Google Fonts Roboto -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"> 
  <!-- Bootstrap core CSS -->
  <link rel="stylesheet" href="<?php echo e(asset('schedule_public/css/bootstrap.css')); ?>">
  <!-- Material Design Bootstrap -->
  <link rel="stylesheet" href="<?php echo e(asset('schedule_public/css/mdb.min.css')); ?>">
  <!-- Your custom styles (optional) -->
  <link rel="stylesheet" href="<?php echo e(asset('schedule_public/css/style.css')); ?>">

  <!-- jQuery -->
  <script type="text/javascript" src="<?php echo e(asset('schedule_public/js/jquery.min.js')); ?>"></script>
  <!-- Moment js for Date Time -->
  <script type="text/javascript" src="<?php echo e(asset('schedule_public/js/moment.js')); ?>"></script>
  

  <style>
    .center {
      height: 100%;
      position: relative;
    }
    .elements {
      text-align:center;
      margin: 0;
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
    }
  </style>
</head>
<body style="height:100%">
  <div class="center">
    <div class="elements">
            <span>Airport</span>
      <select class="mdb-select">
        <?php $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($list->airport_id); ?>"><?php echo e($list->airport_name); ?> (<?php echo e($list->airport_id); ?>)</option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
      <br>
      <br>
      <a id="departure_schedule_button" target="_blank" class="m-3 text-decoration-none">
        <button type="button" class="btn btn-dark p-3 mt-3 mb-3">Departure Schedule</button>
      </a>
      <a id="landing_schedule_button" target="_blank" class="m-3 text-decoration-none">
        <button type="button" class="btn btn-secondary p-3 mt-3 mb-3">Landing Schedule</button>
      </a>	
    </div>
  </div>
  
  <script>
    $('#departure_schedule_button').on('click', function(e){
      window.location.href = "<?php echo e(route('get_departure')); ?>"+"/?airport="+$('.mdb-select').val();
    });
    $('#landing_schedule_button').on('click', function(e){
      window.location.href = "<?php echo e(route('get_landing')); ?>"+"/?airport="+$('.mdb-select').val();
    });
  </script>
  
</body>
</html>
<?php /**PATH E:\Courses\Programming Exercises\PHP\Laravel Project\project\Laravel\resources\views/schedule/schedule_public/airport_list.blade.php ENDPATH**/ ?>