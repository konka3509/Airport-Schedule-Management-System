<?php $__env->startSection('content'); ?>
<div class="container">
<div class="row">
<div class="col-md-4 offset-md-4">
<form action="<?php echo e(route('schedulecreat')); ?>" method="post">
<?php echo csrf_field(); ?>
  <div class="form-group">
    <label for="flight_id">Flight</label>
    <select name="flight_id" id="flight_id" class="form-control <?php $__errorArgs = ['flight_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required autocomplete="flight">
	<?php $__currentLoopData = $flight_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<option value="<?php echo e($flight->id); ?>"><?php echo e($flight->flight_name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
    </select>
  </div>
  
  <div class="form-group">
    <label for="deperture_at">Deperture At</label>
    <input name="deperture_at" type="datetime-local" class="form-control" id="deperture_at" aria-describedby="deperture_at">
  </div>

  <div class="form-group">
    <label for="landing_at">landing At</label>
    <input name="landing_at" type="datetime-local" class="form-control" id="landing_at" aria-describedby="landing_at">
  </div>  
  
  <div class="form-group">
    <label for="departure_airport_id">Deperture Airport</label>
	<select  name="departure_airport_id" id="departure_airport_id" class="form-control <?php $__errorArgs = ['airport_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required autocomplete="airport">
		<?php $__currentLoopData = $airport_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $airport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<option value="<?php echo e($airport->id); ?>"><?php echo e($airport->airport_name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
    </select>
  </div>
  
    <div class="form-group">
    <label for="landing_airport_id">Landing Airport</label>
	<select  name="landing_airport_id" id="landing_airport_id" class="form-control <?php $__errorArgs = ['airport_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required autocomplete="airport">
		<?php $__currentLoopData = $airport_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $airport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<option value="<?php echo e($airport->id); ?>"><?php echo e($airport->airport_name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
    </select>
  </div>
  
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>
</div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Round Kitkat\Desktop\project\Laravel\resources\views/schedule/scheduleinformation.blade.php ENDPATH**/ ?>