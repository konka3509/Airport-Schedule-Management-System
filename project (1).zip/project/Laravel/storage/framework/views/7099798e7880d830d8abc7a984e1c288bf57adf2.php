<?php $__env->startSection('content'); ?>
<div class="container">
<div class="row">
<div class="col-md-4 offset-md-4">
<form action="<?php echo e(route('airportupdate', $list->id)); ?>" method="post">
<?php echo csrf_field(); ?>
  <div class="form-group">
    <label for="airport_name">Airport Name</label>
    <input name="airport_name" type="text" value="<?php echo e($list->airport_name); ?>" class="form-control" id="airport_name" aria-describedby="airport_name">
  </div>

  <div class="form-group">
    <label for="airport_id">Airport ID</label>
    <input name="airport_id" type="text" value="<?php echo e($list->airport_id); ?>" class="form-control" id="airport_id" aria-describedby="airport_id">
  </div>
  <button type="submit" class="btn btn-outline-info">UPDATE</button>
</form>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Courses\Programming Exercises\PHP\Laravel Project\project\Laravel\resources\views/airportinformation/single_read.blade.php ENDPATH**/ ?>