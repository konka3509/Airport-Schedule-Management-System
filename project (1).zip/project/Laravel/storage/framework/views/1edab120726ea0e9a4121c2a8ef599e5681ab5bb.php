<?php $__env->startSection('content'); ?>
<div class="container">
	<a href="<?php echo e(route('addflight')); ?>" class="m-3">
		<button type="button" class="btn btn-outline-primary">Add Flight</button>
	</a>

<div class="row">
<div class="col-md-12"><br>
<table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">SL</th>
      <th scope="col">Flight Name</th>
      <th scope="col">Flight ID</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($loop->iteration); ?></th>
      <td><?php echo e($list->flight_name); ?></td>
      <td><?php echo e($list->flight_id); ?></td>

<td>
<a href="<?php echo e(url('/flight/information/list/edit')); ?>/<?php echo e($list->id); ?>" class="btn btn-outline-success">EDIT</a>
<a href="<?php echo e(url('/flight/information/list/delate')); ?>/<?php echo e($list->id); ?>" class="btn btn-outline-danger">DELETE</a>
</td>
</tr>

 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Courses\Programming Exercises\PHP\Laravel Project\project\Laravel\resources\views/flight/flight_list.blade.php ENDPATH**/ ?>