<?php $__env->startSection('content'); ?>
<div class="container">
<div class="row">
<div class="col-md-4 offset-md-4">
<form action="<?php echo e(route('flightcreat')); ?>" method="post">
<?php echo csrf_field(); ?>
  <div class="form-group">
    <label for="flight_name">Flight Name</label>
    <input name="flight_name" type="text" class="form-control" id="flight_name" aria-describedby="flight_name">
  </div>

  <div class="form-group">
    <label for="flight_id">Flight ID</label>
    <input name="flight_id" type="text" class="form-control" id="flight_id" aria-describedby="flight_id">
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>
</div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Courses\Programming Exercises\PHP\Laravel Project\project\Laravel\resources\views/flight/flightinformation.blade.php ENDPATH**/ ?>