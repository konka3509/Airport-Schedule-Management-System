<?php $__env->startSection('content'); ?>

	<a href="<?php echo e(route('addschedule')); ?>" class="m-3">
		<button type="button" class="btn btn-outline-primary">Add schedule</button>
	</a>
	<div class="container">
	<div class="row">
		<div class="col-md-12">
			<table class="table table-striped">
				<thead>
					<tr>
					  <th scope="col">SL</th>
					  <th scope="col">Flight</th>
					  <th scope="col">Deperture At</th>
					  <th scope="col">Landing At</th>
					  <th scope="col">Deperture Airport</</th>
	                  <th scope="col">Landing Airport</th>
	                  <th scope="col">Status</th>
					  <th scope="col">Delay Landing At</th>
					  <th scope="col">Delay Minutes</th>
					  <th scope="col">Action</th>
					</tr>
				  </thead>
			  <tbody>
			  <?php $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
				  <th scope="row"><?php echo e($loop->iteration); ?></th>
				  <td><?php echo e($list->flight->flight_name); ?></td>
				  <td><?php echo e($list->deperture_at); ?></td>
				  <td><?php echo e($list->landing_at); ?></td>
				   <td><?php echo e($list->landing_airport->airport_name); ?></td>
				   <td><?php echo e($list->departure_airport->airport_name); ?></td>
				  <?php if($list->status == 1 ): ?>
					<td>Regular</td>
				  @ifelse($list->status == 0 )
					<td>Delayed</td>
				  <?php else: ?>	
					<td>Cancelled</td>  
				  <?php endif; ?>
				   <td><?php echo e($list->delay_landing_at); ?></td>
				   <td><?php echo e($list->delay_minutes); ?></td>
			<td>
			<a href="<?php echo e(url('/schedule/information/list/edit')); ?>/<?php echo e($list->id); ?>" class="btn btn-outline-success">EDIT</a>
			<a href="<?php echo e(url('/schedule/information/list/delate')); ?>/<?php echo e($list->id); ?>" class="btn btn-outline-danger">DELETE</a>
			</td>
			</tr>

			 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			  </tbody>
			</table>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Round Kitkat\Desktop\project\Laravel\resources\views/schedule/schedule_list.blade.php ENDPATH**/ ?>