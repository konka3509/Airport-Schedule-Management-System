<?php $__env->startSection('content'); ?>
<div class="container">
<div class="row">
<div class="col-md-4 offset-md-4">
<form action="<?php echo e(route('noticecreat')); ?>" method="post">
<?php echo csrf_field(); ?>
  <div class="form-group">
    <label for="airport_name">Message</label>
    <input name="message" type="text" class="form-control" id="message" aria-describedby="message">
  </div>

  <div class="form-group">
    <label for="active">Status</label>
    <select  name="active" id="active" class="form-control <?php $__errorArgs = ['active'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required autocomplete="active">
		  <option value="1">Active</option>        
		  <option value="2">Not Active</option>        
    </select>
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>
</div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Courses\Programming Exercises\PHP\Laravel Project\project\Laravel\resources\views/notice/noticeinformation.blade.php ENDPATH**/ ?>