<?php $__env->startSection('content'); ?>
<div class="container">
  <label>Date</label>
  <input type="date" id="date">
  <label>Month</label>
  <input type="month" id="month">
  <a id="search" class="btn btn-outline-light"><i class="fa fa-search"></i></a>
  <a onclick="printDiv('printableArea')" class="btn btn-outline-light" title="Print report"><i class="fa fa-print"></i></a>
  <input type="text" id="myInput" placeholder=" Custom Filter" title="Type anythting..." style="float:right">
  <br><span id="error_message" style="color:red"></span>
  
  <script>    
    $('#search').on('click', function(e){
      var date = $('#date').val();
      var month = $('#month').val();
      console.log(date, month);
      if ((date != '' && month != '') || (date == '' && month == '')){
        $('#error_message').text('Please search by Date or Month. One at a time.');
        setTimeout(function(){
          $('#error_message').text('');
        }, 5000);        
      }
      else {
        if (date != ''){
          window.location.href = "/report/?date="+date;
        }
        if (month != ''){
          window.location.href = "/report/?month="+month;
        }
        
      }
    });
  </script>
  
  <div class="row" id="printableArea">
    <div class="col-md-12 offset-md-12"><br>
    <h4 style="text-align: center" id="heading"></h4>
      <table class="table table-striped">
        <thead>
          <tr>
            <th scope="col">SL</th>
            <th scope="col">Airline</th>
            <th scope="col">Flight No</th>
            <th scope="col">Departure From</th>
            <th scope="col">Landing At</th>
            <th scope="col">Departure Time</th>
            <th scope="col">Landing Time</th>
            <th scope="col">Status</th>
            <th scope="col">Delay Landing At</th>
          </tr>
        </thead>
        <tbody id="list">
          <?php $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <th scope="row"><?php echo e($loop->iteration); ?></th>
              <td><?php echo e($list->flight->flight_name); ?></td>
              <td><?php echo e($list->flight->flight_id); ?></td>
              <td><?php echo e($list->departure_airport->airport_name); ?> (<?php echo e($list->departure_airport->airport_id); ?>)</td>
              <td><?php echo e($list->landing_airport->airport_name); ?> (<?php echo e($list->landing_airport->airport_id); ?>)</td>
              <td id="deperture_at_id_<?php echo e($list->id); ?>"><?php echo e($list->deperture_at); ?></td>
              <td id="landing_at_id_<?php echo e($list->id); ?>"></td>
              <td id="status_id<?php echo e($list->id); ?>"><?php echo e($list->status); ?></td>
              <td id="delay_landing_at_id_<?php echo e($list->id); ?>"></td>
            </tr>
            <script>
              document.getElementById('deperture_at_id_<?php echo e($list->id); ?>').innerHTML = (moment("<?php echo e($list->deperture_at); ?>", "YYYY-MM-DD HH:mm:ss").format("LLL"));
              document.getElementById('landing_at_id_<?php echo e($list->id); ?>').innerHTML = (moment("<?php echo e($list->landing_at); ?>", "YYYY-MM-DD HH:mm:ss").format("LLL"));
              
              function set_status(id){
                var status = {
                  0: 'ON TIME',
                  1: 'DELAYED',
                  2: 'RESCHEDULED',
                  3: 'CANCELED',
                  4: 'LANDED',
                  5: 'TAKEN OFF',
                };
                return status[id]; 
              }
              document.getElementById('status_id<?php echo e($list->id); ?>').innerHTML = set_status("<?php echo e($list->status); ?>");
              if("<?php echo e($list->delay_landing_at); ?>" != ""){
                document.getElementById('delay_landing_at_id_<?php echo e($list->id); ?>').innerHTML = (moment("<?php echo e($list->delay_landing_at); ?>", "YYYY-MM-DD HH:mm:ss").format("LLL"));
              }
            
            </script>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
        <p id="no_data" style="text-align: center"></p>
    </div>
  </div>
</div>

<script>
// custom filter
  var input = document.getElementById("myInput");
  input.addEventListener("input", myFunction);
  function myFunction() {
  const filter = document.querySelector('#myInput').value.toUpperCase();
  const trs = document.querySelectorAll('#list tr');
  trs.forEach(tr => tr.style.display = [...tr.children].find(td => td.innerHTML.toUpperCase().includes(filter)) ? '' : 'none');
}

// no data in table
if("<?php echo e($lists); ?>".length == 2){
  $('#no_data').text("No Search Found");
}
// set heading
var heading = location.href.split('date=')[1];
if(heading != undefined){
  heading = moment(heading, "YYYY-MM-DD").format("LL");
} else if(location.href.split('monty=')[1]  != undefined){
  heading = location.href.split('month=')[1];
  heading = moment(heading, "YYYY-MM").format("MMM, YYYY");
}
else{
  heading = moment().format("LL");
}

$('#heading').text('Report of ' + heading);

//print table as report
function printDiv(divName) {
     var printContents = document.getElementById("printableArea").innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
}
</script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Courses\Programming Exercises\PHP\Laravel Project\project\Laravel\resources\views/report/report.blade.php ENDPATH**/ ?>