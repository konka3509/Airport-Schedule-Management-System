<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header">Dashboard</div>

            <div class="card-body">
              <?php if(session('status')): ?>
                <div class="alert alert-success" role="alert">
                  <?php echo e(session('status')); ?>

                </div>
              <?php endif; ?>
					
              <?php if(Auth::user()->user_type == 1): ?>
                <a href="<?php echo e(route('userlist')); ?>" class="m-3 text-decoration-none">
                  <button type="button" class="btn btn-outline-primary p-3 mt-3 mb-3">User Management</button>
                </a>
              <a href="<?php echo e(route('airportlist')); ?>" class="m-3 text-decoration-none">
                <button type="button" class="btn btn-outline-warning p-3 mt-3 mb-3">Airport</button>
              </a>
              <?php endif; ?>
              <a href="<?php echo e(route('flightlist')); ?>" class="m-3 text-decoration-none">
                <button type="button" class="btn btn-outline-success p-3 mt-3 mb-3">Flight</button>
              </a>
              <a href="<?php echo e(route('schedule_list')); ?>" class="m-3 text-decoration-none">
                <button type="button" class="btn btn-outline-info p-3 mt-3 mb-3">Schedule</button>
              </a>	
              <a href="<?php echo e(route('noticelist')); ?>" class="m-3 text-decoration-none">
                <button type="button" class="btn btn-outline-secondary p-3 mt-3 mb-3">Notice</button>
              </a>	
              <a href="<?php echo e(route('report_view')); ?>" class="m-3 text-decoration-none">
                <button type="button" class="btn btn-outline-danger p-3 mt-3 mb-3">Report</button>
              </a>	
              <br>
              <a href="<?php echo e(route('get_airport_list')); ?>" target="_blank" class="m-3 text-decoration-none">
                <button type="button" class="btn btn-dark p-3 mt-3 mb-3">View Schedule</button>
              </a>			
          </div>
        </div>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Courses\Programming Exercises\PHP\Laravel Project\project\Laravel\resources\views/home.blade.php ENDPATH**/ ?>