<?php $__env->startSection('content'); ?>

	<div class="container">
	<a href="<?php echo e(route('addschedule')); ?>" class="m-3">
		<button type="button" class="btn btn-outline-primary">Add schedule</button>
	</a>
	<div class="row">
		<div class="col-md-12"><br>
			<table class="table table-striped">
				<thead>
					<tr>
					  <th scope="col">SL</th>
					  <th scope="col">Flight</th>
					  <th scope="col">Departure At</th>
					  <th scope="col">Landing At</th>
					  <th scope="col">Departure Airport</</th>
	          <th scope="col">Landing Airport</th>
	          <th scope="col">Status</th>
					  <th scope="col">Delay Landing At</th>
					  <th scope="col">Delay Minutes</th>
					  <th scope="col">Action</th>
					</tr>
				  </thead>
			  <tbody> 
			  <?php $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
				  <th scope="row"><?php echo e($loop->iteration); ?></th>
				  <td><?php echo e($list->flight->flight_name); ?> (<?php echo e($list->flight->flight_id); ?>)</td>
				  <td id="deperture_at_id_<?php echo e($list->id); ?>"><?php echo e($list->deperture_at); ?></td>
				  <td id="landing_at_id_<?php echo e($list->id); ?>"><?php echo e($list->landing_at); ?></td>
				  <td><?php echo e($list->departure_airport->airport_name); ?> (<?php echo e($list->departure_airport->airport_id); ?>)</td>
				  <td><?php echo e($list->landing_airport->airport_name); ?> (<?php echo e($list->landing_airport->airport_id); ?>)</td>
				  <?php if($list->status == 0 ): ?>
            <td>ON TIME</td>
				  <?php elseif($list->status == 1 ): ?>
            <td>DELAYED</td>
				  <?php elseif($list->status == 2 ): ?>
            <td>RESCHEDULED</td>
				  <?php elseif($list->status == 3 ): ?>
            <td>CANCELLED</td>
				  <?php elseif($list->status == 4 ): ?>
            <td>LANDED</td>
				  <?php else: ?>	
            <td>TAKEN OFF</td>  
				  <?php endif; ?>
				   <td id="delay_landing_at_id_<?php echo e($list->id); ?>"><?php echo e($list->delay_landing_at); ?></td>
				   <td id="delay_minutes_id_<?php echo e($list->id); ?>"><?php echo e($list->delay_minutes); ?></td>
          <td>
            <a href="<?php echo e(url('/schedule/information/list/edit')); ?>/<?php echo e($list->id); ?>" class="btn btn-outline-success">EDIT</a>
            <a href="<?php echo e(url('/schedule/information/list/delate')); ?>/<?php echo e($list->id); ?>" class="btn btn-outline-danger">DELETE</a>
          </td>
          </tr>
          <script>
              document.getElementById('deperture_at_id_<?php echo e($list->id); ?>').innerHTML = (moment("<?php echo e($list->deperture_at); ?>", "YYYY-MM-DD HH:mm:ss").format("LLL"));
              document.getElementById('landing_at_id_<?php echo e($list->id); ?>').innerHTML = (moment("<?php echo e($list->landing_at); ?>", "YYYY-MM-DD HH:mm:ss").format("LLL"));
              if ("<?php echo e($list->delay_landing_at); ?>" != ""){
                document.getElementById('delay_landing_at_id_<?php echo e($list->id); ?>').innerHTML = (moment("<?php echo e($list->delay_landing_at); ?>", "YYYY-MM-DD HH:mm:ss").format("LLL"));
              }
              if ("<?php echo e($list->delay_minutes); ?>" != ""){
                document.getElementById('delay_minutes_id_<?php echo e($list->id); ?>').innerHTML = "<?php echo e($list->delay_minutes); ?>" + "min";
              }
          </script>
			 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			  </tbody>
			</table>
		</div>
	</div>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Courses\Programming Exercises\PHP\Laravel Project\project\Laravel\resources\views/schedule/schedule_list.blade.php ENDPATH**/ ?>