<!DOCTYPE html>
<html lang="en" id="full_page">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Airport Schedule Management System</title>
  <!-- MDB icon -->
  <link rel="icon" href="img/mdb-favicon.ico" type="image/x-icon">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">
  <!-- Google Fonts Roboto -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"> 
  <!-- Bootstrap core CSS -->
  <link rel="stylesheet" href="<?php echo e(asset('schedule_public/css/bootstrap.css')); ?>">
  <!-- Material Design Bootstrap -->
  <link rel="stylesheet" href="<?php echo e(asset('schedule_public/css/mdb.min.css')); ?>">
  <!-- Your custom styles (optional) -->
  <link rel="stylesheet" href="<?php echo e(asset('schedule_public/css/style.css')); ?>">

  <!-- jQuery -->
  <script type="text/javascript" src="<?php echo e(asset('schedule_public/js/jquery.min.js')); ?>"></script>
  <!-- Moment js for Date Time -->
  <script type="text/javascript" src="<?php echo e(asset('schedule_public/js/moment.js')); ?>"></script>
  

  <style>
    table th{
      font-size: 1.3em;
      font-weight: bold;
    }
    table td{
      font-size: 1em;
    }
  </style>
</head>
<body>

  <!-- Start your project here--> 
  <header>
    <!-- Navbar -->
    <nav class="navbar fixed-top navbar-expand-lg navbar-light white scrolling-navbar">
      <div class="container-fluid">
        <div class="row pl-5 pr-5 w-100" style="font-size:40px;font-weight:bold">
          <div class="col-4">
            <span id="airport_id"></span>    
            <script>
              $('#airport_id').text((window.location.href).split('airport=')[1]);
            </script>
            <img style="width:10%!important" src="<?php echo e(asset('schedule_public/img/custom_images/bangladesh_flag.png')); ?>">          
          </div>
          <div class="col-8" style="text-align:right">
            <span id="current_date" style="font-weight:normal;font-size:.6em"></span>
            <span id="current_time"></span>
            <span style="font-weight:normal;font-size:.3em">Local(GMT+6)</span>
          </div>      
        </div>
      </div>
    </nav>
    <!-- Navbar -->
  </header>
  <!--Main Navigation-->

  <!--Main layout-->
  <main style="margin-top:9%">
    <section class="mx-lg-5 card">  
      <div class="card-body d-sm-flex">
        <div class="col-2">
          <span class="table-danger p-1">Canceled</span>
          <?php if($departure): ?>
            <span class="table-warning p-1">Rescheduled</span>
          <?php else: ?>
            <span class="table-warning p-1">Delay</span>
            <span class="table-info p-1">Rescheduled</span>
          <?php endif; ?>
        </div>
        <div class="col-10">
          <marquee id="marquee" direction="left">
            <script> var notices = ''; </script>
            <?php $__currentLoopData = $notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <script> notices += "<i class='fas fa-angle-double-right' style='color:green'></i> <?php echo e($notice->message); ?> ";</script> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <script>
              $('#marquee').html(notices);
            </script> 
          </marquee>
        </div>
      </div>
    </section>
    <section class="mx-lg-5 card">  
      <div class="card-body d-sm-flex justify-content-between">  
        <!--Table-->
        <table class="table table-striped w-100">
          <!--Table head-->
          <thead>
            <tr>
              <th>#</th>
              <?php if($departure): ?>
                <th>Departure At</th>
              <?php else: ?>
                <th>Landing At</th>
              <?php endif; ?>
              <th>Airline</th>
              <th>Flight No</th>
              <?php if($departure): ?>
              <th>Destination</th>
              <?php else: ?>
                <th>Source</th>
              <?php endif; ?>
              <th>Status</th>
            </tr>
          </thead>
          <!--Table head-->

          <!--Table body-->
          <tbody id="schedule_list_table">
            <?php $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr id="row_<?php echo e($list->id); ?>">
                <th scope="row"><?php echo e($loop->iteration); ?></th>
                <?php if($departure): ?>
                  <td id="deperture_at_id_<?php echo e($list->id); ?>"><?php echo e($list->deperture_at); ?></td>                
                <?php else: ?>
                  <td id="landing_at_id_<?php echo e($list->id); ?>"><?php echo e($list->landing_at); ?></td>                  
                <?php endif; ?>
                
                <td><?php echo e($list->flight->flight_name); ?></td>
                <td><?php echo e($list->flight->flight_id); ?></td>
                <?php if($departure): ?>
                <td class="text-uppercase"><?php echo e($list->landing_airport->airport_name); ?> (<?php echo e($list->landing_airport->airport_id); ?>)</td>
                <?php else: ?>
                  <td class="text-uppercase"><?php echo e($list->departure_airport->airport_name); ?> (<?php echo e($list->departure_airport->airport_id); ?>)</td>
                <?php endif; ?>
                
                
                <?php if($departure): ?>
                  <?php if($list->status == 1 ): ?>
                    <td>TAKEN OFF</td>
                  <?php elseif($list->status == 4 ): ?>
                    <td>TAKEN OFF</td>
                  <?php else: ?>	  
                    <?php if($list->status == 0 ): ?>
                      <td>ON TIME</td>
                    <?php elseif($list->status == 2 ): ?>
                      <td>RESCHEDULED</td>
                      <script>console.log($("#row_<?php echo e($list->id); ?>").addClass("table-warning"))</script>
                    <?php elseif($list->status == 3 ): ?>
                      <td>CANCELLED</td>
                      <script>console.log($("#row_<?php echo e($list->id); ?>").addClass("table-danger"))</script>
                    <?php else: ?>	
                      <td>TAKEN OFF</td>  
                    <?php endif; ?>
                  <?php endif; ?>
                <?php else: ?>
                  <?php if($list->status == 0 ): ?>
                    <td>ON TIME</td>
                  <?php elseif($list->status == 1 ): ?>
                    <td>DELAYED</td>
                    <script>console.log($("#row_<?php echo e($list->id); ?>").addClass("table-warning"))</script>
                  <?php elseif($list->status == 2 ): ?>
                    <td>RESCHEDULED</td> 
                    <script>console.log($("#row_<?php echo e($list->id); ?>").addClass("table-info"))</script>
                  <?php elseif($list->status == 3 ): ?>
                    <td>CANCELLED</td>
                    <script>console.log($("#row_<?php echo e($list->id); ?>").addClass("table-danger"))</script>
                  <?php elseif($list->status == 4 ): ?>
                    <td>LANDED</td>
                  <?php else: ?>	
                    <!-- <td>TAKEN OFF</td>  -->
                    <td>ON TIME</td>  
                  <?php endif; ?>
                <?php endif; ?>
              </tr>
              <script>
                function set_departure_time(status, time){
                  var departure_time = '';
                  if (status == 2){
                    departure_time = "<span><del>"+moment("<?php echo e($list->old_deperture_at); ?>",'YYYY-MM-DD HH:mm:ss').format('LT')+"</del></span>";
                    departure_time += "</br><span style='color:red;'>"+moment(time,'YYYY-MM-DD HH:mm:ss').format('LT')+"</span>";
                  }
                  else {
                    departure_time = moment(time,'YYYY-MM-DD HH:mm:ss').format('LT');
                  }      
                  return departure_time;      
                }
                
                
                function set_landing_time(status, time){
                  var landing_time = '';
                  if (status == 1){
                    landing_time = "<span><del>"+moment("<?php echo e($list->old_landing_at); ?>",'YYYY-MM-DD HH:mm:ss').format('LT')+"</del></span>";
                    landing_time += "</br><span style='color:red;'>"+moment("<?php echo e($list->delay_landing_at); ?>",'YYYY-MM-DD HH:mm:ss').format('LT')+"</span>";
                  }
                  else if (status == 2){
                    landing_time = "<span><del>"+moment("<?php echo e($list->old_landing_at); ?>",'YYYY-MM-DD HH:mm:ss').format('LT')+"</del></span>";
                    landing_time += "</br><span style='color:red;'>"+moment(time,'YYYY-MM-DD HH:mm:ss').format('LT')+"</span>";
                  }
                  else {
                    landing_time = moment(time,'YYYY-MM-DD HH:mm:ss').format('LT');
                  }      
                  return landing_time;      
                }
                <?php if($departure): ?>
                  document.getElementById('deperture_at_id_<?php echo e($list->id); ?>').innerHTML = set_departure_time("<?php echo e($list->status); ?>", "<?php echo e($list->deperture_at); ?>");
                <?php else: ?>
                  document.getElementById('landing_at_id_<?php echo e($list->id); ?>').innerHTML = set_landing_time("<?php echo e($list->status); ?>", "<?php echo e($list->landing_at); ?>");
                <?php endif; ?>      
                
              
              </script>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
          </tbody>
          <!--Table body-->
        </table>
        <!--Table--> 
      </div>
    </section>
  </main>
  <!-- End your project here-->
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="<?php echo e(asset('schedule_public/js/popper.min.js')); ?>"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="<?php echo e(asset('schedule_public/js/bootstrap.min.js')); ?>"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="<?php echo e(asset('schedule_public/js/mdb.min.js')); ?>"></script>
  <!-- Moment js for Date Time -->
  <script type="text/javascript" src="<?php echo e(asset('schedule_public/js/moment.js')); ?>"></script>
  <!-- Your custom scripts (optional) -->
  <script type="text/javascript"></script>
  
  <script>
  
  <!-- Full Screen on Double click -->
    var elem = document.getElementById("full_page");
    elem.ondblclick = function() {
      fullscreen();
    }
    function fullscreen() {
      var isInFullScreen = (document.fullscreenElement && document.fullscreenElement !== null) ||
          (document.webkitFullscreenElement && document.webkitFullscreenElement !== null) ||
          (document.mozFullScreenElement && document.mozFullScreenElement !== null) ||
          (document.msFullscreenElement && document.msFullscreenElement !== null);

      var docElm = document.documentElement;
      if (!isInFullScreen) {
          if (docElm.requestFullscreen) {
              docElm.requestFullscreen();
          } else if (docElm.mozRequestFullScreen) {
              docElm.mozRequestFullScreen();
          } else if (docElm.webkitRequestFullScreen) {
              docElm.webkitRequestFullScreen();
          } else if (docElm.msRequestFullscreen) {
              docElm.msRequestFullscreen();
          }
      } else {
          if (document.exitFullscreen) {
              document.exitFullscreen();
          } else if (document.webkitExitFullscreen) {
              document.webkitExitFullscreen();
          } else if (document.mozCancelFullScreen) {
              document.mozCancelFullScreen();
          } else if (document.msExitFullscreen) {
              document.msExitFullscreen();
          }
      }
    }
    <!-- End of Full Screen on Double click -->
    
    <!-- Current Date Time -->
    setInterval(function(){
      $('#current_date').html(moment().format('dddd, MMMM Do YYYY,'));
      $('#current_time').html(moment().format('h:mm:ss a'));
    }, 1000);    
    <!-- End of Current Date Time -->
    
    
    // Ajax operation
    
    // getting schedule list
    // $.ajax({
      // url: "<?php echo e(route('get_departure_list', ['airport_id' => '1'])); ?>",
      // success: function(e){
        // console.log(e);
        // $.each(e, function(index, value){
          // var row = "<tr>";
          // row += "<th scope='row'>"+(parseInt(index)+1)+"</th>";
          // row += "<td>"+set_departure_time(value)+"</td>";
          // row += "<td>"+value.flight_id+"</td>";
          // row += "<td>"+value.landing_airport_id+"</td>";
          // row += "<td>"+value.flight_id+"</td>";
          // row += "<td>"+set_status(value.status)+"</td>";
          // row += "</tr>";
          // $('#schedule_list_table').append(row);          
        // });        
      // }      
    // });
    
    // function set_departure_time(value){
      // var departure_time = '';
      // if (value.status == 2){
        // departure_time = "<span><del>"+moment(value.old_deperture_at,'YYYY-MM-DD HH:mm:ss').format('LT')+"</del></span>";
        // departure_time += "</br><span style='color:red;'>"+moment(value.deperture_at,'YYYY-MM-DD HH:mm:ss').format('LT')+"</span>";
      // }
      // else {
        // departure_time = moment(value.deperture_at,'YYYY-MM-DD HH:mm:ss').format('LT');
      // }      
      // return departure_time;      
    // }
    
    // function set_status(id){
      // var status = {
        // 0: 'ON TIME',
        // 1: 'DELAYED',
        // 2: 'RESCHEDULED',
        // 3: 'CANCELED',
        // 4: 'LANDED',
        // 5: 'TAKEN OFF',
      // };
      // console.log(id);
      // return status[id];      
    // }
    
    
    
    
    // setTimeout(function() { document.getElementById('frame').contentWindow.location.reload(); }, 6000);
    // <iframe id="frame" src="<?php echo e(route('get_departure_list')); ?>" height="100%" width="100%" frameborder="0">Your browser doesnot support iframes<a href="myPageURL.htm"> click here to view the page directly. </a></iframe>
    
    
  </script>

</body>
</html>
<?php /**PATH E:\Courses\Programming Exercises\PHP\Laravel Project\project\Laravel\resources\views/schedule/schedule_public/index.blade.php ENDPATH**/ ?>