<!DOCTYPE html>
<html lang="en" id="full_page">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Airport Schedule Management System</title>
  <!-- MDB icon -->
  <link rel="icon" href="img/mdb-favicon.ico" type="image/x-icon">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">
  <!-- Google Fonts Roboto -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"> 
  <!-- Bootstrap core CSS -->
  <link rel="stylesheet" href="<?php echo e(asset('schedule_public/css/bootstrap.css')); ?>">
  <!-- Material Design Bootstrap -->
  <link rel="stylesheet" href="<?php echo e(asset('schedule_public/css/mdb.min.css')); ?>">
  <!-- Your custom styles (optional) -->
  <link rel="stylesheet" href="<?php echo e(asset('schedule_public/css/style.css')); ?>">
  

  <style>
    table th{
      font-size: 1.3em;
      font-weight: bold;
    }
    table td{
      font-size: 1.3em;
    }
  </style>
</head>
<body>

  <!-- Start your project here--> 
  <header>
    <!-- Navbar -->
    <nav class="navbar fixed-top navbar-expand-lg navbar-light white scrolling-navbar">
      <div class="container-fluid">
        <div class="row pl-5 pr-5 w-100" style="font-size:40px;font-weight:bold">
          <div class="col-4">
            <span>DAC</span>          
            <img style="width:10%!important" src="img/custom_images/bangladesh_flag.png">          
          </div>
          <div class="col-8" style="text-align:right">
            <span id="current_date" style="font-weight:normal;font-size:.6em"></span>
            <span id="current_time"></span>
            <span style="font-weight:normal;font-size:.3em">Local(GMT+6)</span>
          </div>      
        </div>
      </div>
    </nav>
    <!-- Navbar -->
  </header>
  <!--Main Navigation-->

  <!--Main layout-->
  <main style="margin-top:9%">
    <section class="mx-lg-5 card">  
      <div class="card-body d-sm-flex">
        <div class="col-2">
          <span class="table-danger p-1">Flight Canceled</span>
          <span class="table-warning p-1">Flight Delay</span>
        </div>
        <div class="col-10">
          <marquee direction="left">A scrolling text created with HTML Marquee element.</marquee>
        </div>
      </div>
    </section>
    <section class="mx-lg-5 card">  
      <div class="card-body d-sm-flex justify-content-between">  
        <!--Table-->
        <table class="table table-striped w-100">
          <!--Table head-->
          <thead>
            <tr>
              <th>#</th>
              <th>Name</th>
              <th>Surname</th>
              <th>Country</th>
              <th>City</th>
              <th>Position</th>
              <th>Age</th>
            </tr>
          </thead>
          <!--Table head-->

          <!--Table body-->
          <tbody>
            <tr class="table-info">
              <th scope="row">1</th>
              <td>Kate</td>
              <td>Moss</td>
              <td>USA</td>
              <td>New York City</td>
              <td>Web Designer</td>
              <td>23</td>
            </tr>
            <tr>
              <th scope="row">2</th>
              <td>Anna</td>
              <td>Wintour</td>
              <td>United Kingdom</td>
              <td>London</td>
              <td>Frontend Developer</td>
              <td>36</td>
            </tr>
            <tr class="table-danger">
              <th scope="row">3</th>
              <td>Tom</td>
              <td>Bond</td>
              <td>Spain</td>
              <td>Madrid</td>
              <td>Photographer</td>
              <td>25</td>
            </tr>
            <tr>
              <th scope="row">4</th>
              <td>Jerry</td>
              <td>Horwitz</td>
              <td>Italy</td>
              <td>Bari</td>
              <td>Editor-in-chief</td>
              <td>41</td>
            </tr>
            <tr class="table-warning">
              <th scope="row">5</th>
              <td>Janis</td>
              <td>Joplin</td>
              <td>Poland</td>
              <td>Warsaw</td>
              <td>Video Maker</td>
              <td>39</td>
            </tr>
            <tr>
              <th scope="row">6</th>
              <td>Gary</td>
              <td>Winogrand</td>
              <td>Germany</td>
              <td>Berlin</td>
              <td>Photographer</td>
              <td>37</td>
            </tr>
            <tr class="table-info">
              <th scope="row">7</th>
              <td>Angie</td>
              <td>Smith</td>
              <td>USA</td>
              <td>San Francisco</td>
              <td>Teacher</td>
              <td>52</td>
            </tr>
            <tr>
              <th scope="row">8</th>
              <td>John</td>
              <td>Mattis</td>
              <td>France</td>
              <td>Paris</td>
              <td>Actor</td>
              <td>28</td>
            </tr>
            <tr class="table-info">
              <th scope="row">9</th>
              <td>Otto</td>
              <td>Morris</td>
              <td>Germany</td>
              <td>Munich</td>
              <td>Singer</td>
              <td>35</td>
            </tr>
            <tr>
              <th scope="row">10</th>
              <td>Otto</td>
              <td>Morris</td>
              <td>Germany</td>
              <td>Munich</td>
              <td>Singer</td>
              <td>35</td>
            </tr>
          </tbody>
          <!--Table body-->
        </table>
        <!--Table--> 
      </div>
    </section>
  </main>
  <!-- End your project here-->

  <!-- jQuery -->
  <script type="text/javascript" src="<?php echo e(asset('schedule_public/js/jquery.min.js')); ?>"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="<?php echo e(asset('schedule_public/js/popper.min.js')); ?>"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="<?php echo e(asset('schedule_public/js/bootstrap.min.js')); ?>"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="<?php echo e(asset('schedule_public/js/mdb.min.js')); ?>"></script>
  <!-- Moment js for Date Time -->
  <script type="text/javascript" src="<?php echo e(asset('schedule_public/js/moment.js')); ?>"></script>
  <!-- Your custom scripts (optional) -->
  <script type="text/javascript"></script>
  
  <script>
  
  <!-- Full Screen on Double click -->
    var elem = document.getElementById("full_page");
    elem.ondblclick = function() {
      fullscreen();
    }
    function fullscreen() {
      var isInFullScreen = (document.fullscreenElement && document.fullscreenElement !== null) ||
          (document.webkitFullscreenElement && document.webkitFullscreenElement !== null) ||
          (document.mozFullScreenElement && document.mozFullScreenElement !== null) ||
          (document.msFullscreenElement && document.msFullscreenElement !== null);

      var docElm = document.documentElement;
      if (!isInFullScreen) {
          if (docElm.requestFullscreen) {
              docElm.requestFullscreen();
          } else if (docElm.mozRequestFullScreen) {
              docElm.mozRequestFullScreen();
          } else if (docElm.webkitRequestFullScreen) {
              docElm.webkitRequestFullScreen();
          } else if (docElm.msRequestFullscreen) {
              docElm.msRequestFullscreen();
          }
      } else {
          if (document.exitFullscreen) {
              document.exitFullscreen();
          } else if (document.webkitExitFullscreen) {
              document.webkitExitFullscreen();
          } else if (document.mozCancelFullScreen) {
              document.mozCancelFullScreen();
          } else if (document.msExitFullscreen) {
              document.msExitFullscreen();
          }
      }
    }
    <!-- End of Full Screen on Double click -->
    
    <!-- Current Date Time -->
    setInterval(function(){
      $('#current_date').html(moment().format('dddd, MMMM Do YYYY,'));
      $('#current_time').html(moment().format('h:mm:ss a'));
    }, 1000);    
    <!-- End of Current Date Time -->
  </script>

</body>
</html>
<?php /**PATH C:\Users\Round Kitkat\Desktop\project\Laravel\resources\views/schedule/schedule_public/index.blade.php ENDPATH**/ ?>