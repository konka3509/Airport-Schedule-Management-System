<?php $__env->startSection('content'); ?>
<div class="container">
<div class="row">
<div class="col-md-4 offset-md-4">
<form action="<?php echo e(route('userupdate', $list->id)); ?>" method="post">
<?php echo csrf_field(); ?>
  <div class="form-group">
    <label for="name">Name</label>
    <input name="name" type="text" value="<?php echo e($list->name); ?>" class="form-control" id="name" aria-describedby="name">
  </div>

  <div class="form-group">
    <label for="email">Email address</label>
    <input name="email" type="email" value="<?php echo e($list->email); ?>" class="form-control" id="email" aria-describedby="emailHelp">
  </div>
  
  <div class="form-group">
    <label for="user_type">User Type</label>	
      <select  name="user_type" id="user_type" class="form-control <?php $__errorArgs = ['user_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required autocomplete="user_type">
        <option value="1">Admin</option>
        <option value="2">Manager</option>
      </select>
   </div>
   <script>
		var user_type = document.getElementById("user_type").value = <?php echo e($list->user_type); ?>;
	</script>

  <div class="form-group">
    <label for="password">Password</label>
    <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="new-password">
  </div>

  <div class="form-group">
    <label for="airport_id">Airport</label>
	<select  name="airport_id" id="airport_id" class="form-control <?php $__errorArgs = ['airport_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required autocomplete="airport">
		<?php $__currentLoopData = $airport_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $airport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<option value="<?php echo e($airport->id); ?>"><?php echo e($airport->airport_name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
    </select>
  </div>
  <button type="submit" class="btn btn-outline-info">UPDATE</button>
</form>
</div>
</div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Round Kitkat\Desktop\project\Laravel\resources\views/auth/single_read.blade.php ENDPATH**/ ?>